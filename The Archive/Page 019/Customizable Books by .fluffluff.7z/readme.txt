You can edit these in any way and repost them if you like. I'd like to see different styles of books! And also memes

If you try to edit any of the textures in a program that doesn't support transparency, the high-res portion may not save correctly.

If you want to remove the high-res part entirely, replace the obj file with the Alternative version.


Like all 3D-Prints, each type of book you use needs to have an obj file with a matching name to the png texture file. For example:

book_red.obj
+
book_red.png
=
one type of book


book_red.obj
+
book_red.png
+
book_blue.obj
+
book_blue.png
=
two different books


awdawdawd.obj
+
awdawdawd.png
=
one book with a dumb name

So if you want to have multiple books, keep this in mind and rename the files accordingly.


Note for editing the model/UVs:

There are 4 transparent planes surrounding the book cover: one on front, one on the back, and two along the spine