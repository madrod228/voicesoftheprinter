Models and texture by breakfast.club on Discord. Edit and use howveer you like.

NOTE: The space rug requires use fo the "stick method" as it is too big for the printer:

1) copy stick.obj to your printer folder and rename it to the name of the mesh you want it to become (spacerug.obj)
2) print and place the stick in-game (in this case I reccomend a larger area such as the bedroom or control room.)
3) delete the copy of the stick mesh and replace it with the real mesh, then reload the game. 
4) Voilà! Your stick(s) should have magically changed into rugs!