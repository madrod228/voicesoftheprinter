Models and texture by breakfast.club on Discord. Edit and use howveer you like.

Recommended to nail down the stand, sometimes VotV physics get funky with it. 