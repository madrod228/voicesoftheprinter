
The 4 pngs are differnt basically the same texture, just different faces.
- "sleep mode" text and face
- just the face
- just the text
- a blank / black screen (like normal Kerfur in sleep mode)

You gonna have to choose one .png of your liking and name the .png and .obj the same name.

Hope yall like it, have fun <3

PockPock