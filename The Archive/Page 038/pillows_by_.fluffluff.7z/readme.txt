Feel free to edit the patterns!

Pillow model
https://www.turbosquid.com/3d-models/model-1571253

Pillow texture (white/base)
https://www.freepik.com/free-photo/simple-smooth-fabric-textured-background_17593140.htm

Tropical flower texture
https://www.freepik.com/free-vector/hand-drawn-summer-tropical-pattern_13722384.htm

Green plaid
https://www.freepik.com/free-vector/flat-christmas-plaid-pattern-design_20286265.htm

Brown diamonds
https://www.freepik.com/free-vector/vector-illustration-ukrainian-folk-seamless-pattern-ornament-ethnic-ornament-border-element-traditional-ukrainian-belarusian-folk-art-knitted-embroidery-pattern-vyshyvanka_1283234.htm